 // int number;
    // cout << "Masukkan angka integer: ";
    // cin >> number;

    // if (number > 0)
    // {
    //     cout << number << " is a postive number" << endl;
    //     if (number % 2 == 0)
    //     {
    //         cout << "Also even number" << endl;
    //     }
    //     else
    //     {
    //         cout << "Also odd number" << endl;
    //     }
    // }
    // else if (number < 0)
    // {
    //     cout << number << " is a negative number" << endl;
    //     if (number % 2 == 0)
    //     {
    //         cout << "Also even number" << endl;
    //     }
    //     else
    //     {
    //         cout << "Also odd number" << endl;
    //     }
    // }
    // else
    // {
    //     cout << number << "is a zero number" << endl;
    // }